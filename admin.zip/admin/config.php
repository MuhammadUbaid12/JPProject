<?php
$server_name= "208.109.60.100";
$user_name= "cso3qwk9mv4n";
$password= "Esgpwp8901@";
$database_name= "mp_ecommerce";
$config= mysqli_connect($server_name , $user_name , $password , $database_name); 
if ($config) { 
// echo "connected" ; 
}
?> 